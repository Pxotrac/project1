# Inventy-Management-System-for-a-Hotel
This is a full kitchen, bar, restaurant and hotel inventy managemnat system for a hotel
