<html>
<head>
	<title>Error 500</title>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url().'css/css/bootstrap.css';?>">
</head>
<body>
	<div class="container">
	<div class="panel panel-danger">
      <div class="panel-heading">Error 500 Invalid data</div>
      <div class="panel-body">Please check the form again correct the error. And
      Try again. </div>
      <div class="panel-footer"><a href="<?php echo base_url().'user';?>">back to dashboard</a></div>
    </div>
    </div>

</body>
</html>